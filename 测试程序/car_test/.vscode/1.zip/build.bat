@echo off

REM ��ȡ�ű�����Ŀ¼
set SCRIPT_DIR=%~dp0

REM ���ÿ�·��
set path_lib=%SCRIPT_DIR%compiler/includeRTOSE7
set "COMPILER_BIN_DIR=%SCRIPT_DIR%compiler\ARM_v7\bin"

REM ��ȡ�����Դ�ļ�·��
set path_src=%~f1

REM ��ȡ����ļ�����������չ����
set path_out_name=%~dpn1

REM ==================== ����Ĭ������ ====================
if exist "%path_out_name%.o" del /f /q "%path_out_name%.o" >nul 2>&1
if exist "%path_out_name%.bin" del /f /q "%path_out_name%.bin" >nul 2>&1
if exist "%path_out_name%.elf" del /f /q "%path_out_name%.o" >nul 2>&1
if exist "%path_out_name%.map" del /f /q "%path_out_name%.bin" >nul 2>&1

REM ============================================================

echo Lib Path:     %path_lib%
echo Source Path:  %path_src%
echo Output Name:  %path_out_name%

rem cmd0 - ����׶�
"%COMPILER_BIN_DIR%\arm-none-eabi-gcc.exe" -I%path_lib% -mcpu=cortex-m7 -mthumb  -mfpu=fpv5-d16 -mfloat-abi=hard -fsigned-char -Os -w -gdwarf-2 -ffunction-sections  -DF_CPU=480000000UL -std=gnu11 -c %path_src% -o %path_out_name%.o

REM �������Ƿ����
if %errorlevel% neq 0 (
    echo [ERROR] GCC Compilation failed!
    goto ON_ERROR
)

rem cmd1 - ���ӽ׶�
"%COMPILER_BIN_DIR%\arm-none-eabi-gcc.exe" -mcpu=cortex-m7 -mthumb -mfpu=fpv5-d16 -mfloat-abi=hard  -specs=nano.specs -L %path_lib%/o -T STM32H743ZITX_FLASH.ld -Wl,--gc-sections -Wl,-Map=%path_out_name%.map,-cref   %path_lib%/o/malloc.o   %path_lib%/o/piclib.o   %path_lib%/o/hufftabs.o   %path_lib%/o/stproc.o   %path_lib%/o/dqchan.o   %path_lib%/o/polyphase.o   %path_lib%/o/dct32.o   %path_lib%/o/trigtabs.o   %path_lib%/o/imdct.o   %path_lib%/o/subband.o   %path_lib%/o/dequant.o   %path_lib%/o/huffman.o   %path_lib%/o/scalfact.o   %path_lib%/o/bitstream.o   %path_lib%/o/mp3tabs.o   %path_lib%/o/buffers.o   %path_lib%/o/mp3dec.o   %path_lib%/o/mp3Player.o   %path_lib%/o/jdy24.o   %path_lib%/o/exfuns.o   %path_lib%/o/event_groups.o   %path_lib%/o/croutine.o   %path_lib%/o/tjpgd.o   %path_lib%/o/syscalls.o   %path_lib%/o/stm32h7xx_hal_sd_ex.o   %path_lib%/o/timers.o   %path_lib%/o/es8311.o   %path_lib%/o/stm32h7xx_hal_exti.o   %path_lib%/o/stm32h7xx_hal_dma_ex.o   %path_lib%/o/stm32h7xx_hal_pwr.o   %path_lib%/o/stm32h7xx_hal_mdma.o   %path_lib%/o/stm32h7xx_hal_hsem.o   %path_lib%/o/delay.o   %path_lib%/o/sysmem.o   %path_lib%/o/stm32h7xx_hal_i2s.o   %path_lib%/o/stm32h7xx_hal_tim_ex.o   %path_lib%/o/stm32h7xx_it.o   %path_lib%/o/I2C_Soft.o   %path_lib%/o/lcd_gt911.o   %path_lib%/o/ccsbcs.o   %path_lib%/o/diskio.o   %path_lib%/o/stm32h7xx_ll_fmc.o   %path_lib%/o/stm32h7xx_hal_sram.o   %path_lib%/o/stm32h7xx_hal_uart_ex.o   %path_lib%/o/stm32h7xx_hal_uart.o   %path_lib%/o/stm32h7xx_hal_pwr_ex.o   %path_lib%/o/stm32h7xx_hal_pcd_ex.o   %path_lib%/o/stm32h7xx_ll_usb.o   %path_lib%/o/stm32h7xx_hal_pcd.o   %path_lib%/o/usbd_storage_if.o   %path_lib%/o/usbd_msc.o   %path_lib%/o/usbd_desc.o   %path_lib%/o/usbd_conf.o   %path_lib%/o/usbd_msc_scsi.o   %path_lib%/o/usbd_msc_data.o   %path_lib%/o/usbd_msc_bot.o   %path_lib%/o/usbd_ctlreq.o   %path_lib%/o/usbd_core.o   %path_lib%/o/usbd_ioreq.o   %path_lib%/o/usb_device.o   %path_lib%/o/stm32h7xx_hal_flash_ex.o   %path_lib%/o/stm32h7xx_hal_flash.o   %path_lib%/o/flash_if.o   %path_lib%/o/stm32h7xx_hal_msp.o   %path_lib%/o/syscall.o   %path_lib%/o/ff.o   %path_lib%/o/file_mgt.o   %path_lib%/o/freertos.o   %path_lib%/o/sdmmc.o   %path_lib%/o/heap_4.o   %path_lib%/o/list.o   %path_lib%/o/port.o   %path_lib%/o/queue.o   %path_lib%/o/stm32h7xx_ll_sdmmc.o   %path_lib%/o/stm32h7xx_hal_sd.o   %path_lib%/o/bsp_driver_sd.o   %path_lib%/o/cmsis_os.o   %path_lib%/o/sd_diskio.o   %path_lib%/o/ff_gen_drv.o   %path_lib%/o/fatfs.o   %path_lib%/o/lcd_st7789v.o   %path_lib%/o/stm32h7xx_hal_cortex.o   %path_lib%/o/stm32h7xx_hal_dma.o   %path_lib%/o/stm32h7xx_hal_tim.o   %path_lib%/o/stm32h7xx_hal_adc_ex.o   %path_lib%/o/stm32h7xx_hal_rcc_ex.o   %path_lib%/o/stm32h7xx_hal_rcc.o   %path_lib%/o/stm32h7xx_hal_adc.o   %path_lib%/o/startup_stm32h743zitx.o   %path_lib%/o/system_stm32h7xx.o   %path_lib%/o/jmkernel.o   %path_lib%/o/stm32h7xx_hal.o   %path_lib%/o/tasks.o   %path_lib%/o/stm32h7xx_hal_gpio.o %path_out_name%.o     -lm -lc -lnosys -o  %path_out_name%.elf

REM �����ص� 2����������Ƿ����
if %errorlevel% neq 0 (
    echo [ERROR] GCC Linking failed!
    goto ON_ERROR
)

rem cmd2 - ���� bin �ļ�
"%COMPILER_BIN_DIR%\arm-none-eabi-objcopy.exe" -O binary %path_out_name%.elf %path_out_name%.bin

REM ========== �첽�������ؼ�� ==========
echo.
echo [INFO] Starting download checker...
set "SRC_NAME=%~n1"

REM ��ʽ��·����װΪ��׼�������������ڴ���ʱǿ�Ƽ����ⲿ˫����
set "PARAM_BIN_PATH=%path_out_name%.bin"
set "PARAM_TARGET_NAME=%SRC_NAME%.bin"

call "%SCRIPT_DIR%download.bat" "%PARAM_BIN_PATH%" "%PARAM_TARGET_NAME%"
goto END

:ON_ERROR
echo [STATUS] Build stopped due to errors.
exit /b 1

:END
echo [DONE] Compilation finished.
exit /b 1